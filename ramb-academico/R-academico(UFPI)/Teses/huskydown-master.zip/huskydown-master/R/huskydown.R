#' huskydown: A package for creating undergraduate, Masters, and PhD theses
#'using R Markdown
#' @docType package
#' @name huskydown
NULL
